import java.util.Scanner;

import battles.Battle;
import game.Game;
import game.SaveGameManager;
import trainers.Trainer;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Load game or start new game
        Game game = SaveGameManager.loadGame(); // Load the game, or start a new one if no save exists

        while (true) {
            System.out.print("Enter command: ");
            String command = scanner.nextLine();
            switch (command) {
                case "save":
                    SaveGameManager.saveGame(game);
                    System.out.println("Game saved successfully.");
                    break;
                case "load":
                    game = SaveGameManager.loadGame();
                    System.out.println("Game loaded successfully.");
                    break;
                case "restart":
                    SaveGameManager.restartGame();
                    game = SaveGameManager.loadGame(); // Reloading game after reset
                    System.out.println("Game restarted.");
                    break;
                case "create trainer":
                    System.out.print("Enter trainer name: ");
                    String name = scanner.nextLine();
                    Trainer trainer = new Trainer(name);
                    game.addTrainer(trainer);
                    System.out.println("Trainer " + name + " created.");
                    break;
                case "exit":
                    System.out.println("Exiting game...");
                    System.exit(0);
                    break;
                case "start battle":
                    System.out.print("Enter name of Trainer 1: ");
                    String trainer1Name = scanner.nextLine();
                    System.out.print("Enter name of Trainer 2: ");
                    String trainer2Name = scanner.nextLine();
                    Trainer trainer1 = game.findTrainerByName(trainer1Name);
                    Trainer trainer2 = game.findTrainerByName(trainer2Name);
                    if (trainer1 != null && trainer2 != null) {
                        Battle battle = new Battle(trainer1, trainer2);
                        battle.start();
                    } else {
                        System.out.println("One or both trainers not found.");
                    }
                    break;
                case "toggle day/night":
                    game.toggleDayNight();
                    break;
                  
                default:
                    System.out.println("Unknown command. Please try again.");
            }
        }
    }
}
