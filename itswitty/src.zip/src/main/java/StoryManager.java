import battles.Battle;
import game.Game;
import trainers.Trainer;

public class StoryManager {
    private Game game;
    private int currentPhase;
    private final int totalPhases = 20;

    public StoryManager(Game game) {
        this.game = game;
        this.currentPhase = 0;
    }

    public boolean startNextPhase() {
        if (currentPhase < totalPhases) {
            Trainer player = game.getPlayer();
            Trainer opponent = game.getTrainers().get(currentPhase);
            Battle battle = new Battle(player, opponent);
            boolean result = battle.start();
            
            if (result) {
                currentPhase++;
                if (currentPhase == totalPhases) {
                    System.out.println("All phases complete! You can now challenge the champion.");
                }
                return true;
            } else {
                System.out.println("You lost the battle. Try again to progress the story.");
                return false;
            }
        } else {
            boolean result = challengeChampion();
            return result;
        }
    }
    

    private boolean challengeChampion() {
        Trainer player = game.getPlayer();
        Trainer champion = game.getChampion();
        Battle battle = new Battle(player, champion);
        return battle.start();
    }

    public int getCurrentPhase() {
        return currentPhase;
    }

    public void setCurrentPhase(int phase) {
        this.currentPhase = phase;
    }
}
