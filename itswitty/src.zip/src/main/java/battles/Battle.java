package battles;


import trainers.Trainer;

public class Battle {
    private Trainer player;
    private Trainer opponent;

    public Battle(Trainer player, Trainer opponent) {
        this.player = player;
        this.opponent = opponent;
    }

    public boolean start() {
        while (player.hasActiveCodeAMon() && opponent.hasActiveCodeAMon()) {
            // Simulate battle rounds
            // Implement actual attack, defense, and health checks.
            player.attack(opponent.getCurrentCodeAMon());
            if (!opponent.hasActiveCodeAMon()) {
                return true; // Player wins
            }

            opponent.attack(player.getCurrentCodeAMon());
            if (!player.hasActiveCodeAMon()) {
                return false; // Opponent wins
            }
        }
        return !player.hasActiveCodeAMon(); // Return false if player has no active CodeAMon left
    }
}
