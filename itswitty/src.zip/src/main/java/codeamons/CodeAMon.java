package codeamons;

import java.util.Random;

public class CodeAMon {
    private String type;
    private int level;
    private int attack;
    private int defense;
    private int health;

    public void levelUp() {
        level++;
        attack += new Random().nextInt(5) + 1;
        defense += new Random().nextInt(5) + 1;
        health += 10;
    }


    public CodeAMon(String type, int attack, int defense, int health) {
        this.type = type;
        this.attack = attack;
        this.defense = defense;
        this.health = health;
    }

    // Getters and Setters
    public String getType() {
        return type;
    }

    public int getAttack() {
        return attack;
    }

    public int getDefense() {
        return defense;
    }

    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        this.health = health;
    }

}