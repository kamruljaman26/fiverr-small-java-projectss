package codeamons;

public class CodeAMonBuilder {
    private String type;
    private int attack;
    private int defense;
    private int health;

    public CodeAMonBuilder setType(String type) {
        this.type = type;
        return this;
    }

    public CodeAMonBuilder setAttack(int attack) {
        this.attack = attack;
        return this;
    }

    public CodeAMonBuilder setDefense(int defense) {
        this.defense = defense;
        return this;
    }

    public CodeAMonBuilder setHealth(int health) {
        this.health = health;
        return this;
    }

    public CodeAMon build() {
        return new CodeAMon(type, attack, defense, health);
    }
}
