package codeamons;

public class DarkCodeAMon extends CodeAMon{
    public DarkCodeAMon(int attack, int defense, int health) {
        super("Dark", attack, defense, health);
    }
}
