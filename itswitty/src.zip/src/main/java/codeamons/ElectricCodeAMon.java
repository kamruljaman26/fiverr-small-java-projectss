package codeamons;

public class ElectricCodeAMon extends CodeAMon {
    public ElectricCodeAMon(int attack, int defense, int health) {
        super("Electric", attack, defense, health);
    }
}
