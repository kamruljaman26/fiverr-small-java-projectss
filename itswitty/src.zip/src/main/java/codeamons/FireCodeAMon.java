package codeamons;

public class FireCodeAMon extends CodeAMon {
    public FireCodeAMon(int attack, int defense, int health) {
        super("Fire", attack, defense, health);
    }
}
