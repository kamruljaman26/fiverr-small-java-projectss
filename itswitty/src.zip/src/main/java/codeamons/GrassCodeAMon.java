package codeamons;

public class GrassCodeAMon extends CodeAMon {
    public GrassCodeAMon(int attack, int defense, int health) {
        super("Grass", attack, defense, health);
    }
}
