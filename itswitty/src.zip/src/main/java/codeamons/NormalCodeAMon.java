package codeamons;

public class NormalCodeAMon extends CodeAMon{
    public NormalCodeAMon(int attack, int defense, int health) {
        super("Normal", attack, defense, health);
    }
}
