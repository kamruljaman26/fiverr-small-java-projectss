package codeamons;

public class WaterCodeAMon extends CodeAMon {
    public WaterCodeAMon(int attack, int defense, int health) {
        super("Water", attack, defense, health);
    }
}
