package game;

public class DayNightCycle {
    private boolean isDaytime = true;  // Starting with daytime

    public void toggleDayNight() {
        isDaytime = !isDaytime;
        System.out.println("It is now " + (isDaytime ? "daytime." : "nighttime."));
    }

    public boolean isDaytime() {
        return isDaytime;
    }
}
