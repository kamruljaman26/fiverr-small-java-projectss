package game;

import trainers.Trainer;

import java.util.ArrayList;
import java.util.List;

public class Game {
    private static Game instance;
    private List<Trainer> trainers;
    private DayNightCycle dayNightCycle = new DayNightCycle();

    public Game() {
        trainers = new ArrayList<>();
    }

    public static Game getInstance() {
        if (instance == null) {
            instance = new Game();
        }
        return instance;
    }

    public void toggleDayNight() {
        dayNightCycle.toggleDayNight();
    }

    public boolean isDaytime() {
        return dayNightCycle.isDaytime();
    }
    
    public void start() {
        System.out.println("Welcome to Code-a-Mon!");
        // Initialization code and game loop
    }
}
