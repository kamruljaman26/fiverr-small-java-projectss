package game;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import battles.Battle;
import codeamons.CodeAMon;
import trainers.Trainer;

public class GameInitializer {
    private static final List<String> trainerNames = Arrays.asList(
        "Alice", "Bob", "Cindy", "Dan", "Eve", "Frank", "Grace", "Hank", 
        "Ivy", "Jack", "Kathy", "Leo", "Mona", "Nick", "Olivia", "Pete", 
        "Quinn", "Rita", "Sam", "Tina"
    );

    private static final String[] codeamonTypes = {"Fire", "Water", "Grass", "Electric", "Dark", "Normal"};

    public static void initializeGame(Game game) {
        Random rand = new Random();

        // Create all trainers with one starting CodeAMon each
        for (String name : trainerNames) {
            String type = codeamonTypes[rand.nextInt(codeamonTypes.length)];
            Trainer trainer = new Trainer(name);
            CodeAMon startingMon = createRandomCodeAMon(type);
            trainer.addCodeAMon(startingMon);
            game.addTrainer(trainer);
        }

        // Special setup for rival and player
        Trainer player = new Trainer("Player");
        CodeAMon codeAChu = new CodeAMon("Electric", 5, 5, 5); // Weak level 5 electric rat
        player.addCodeAMon(codeAChu);

        Trainer rival = new Trainer("BAD J");
        CodeAMon marshCode = new CodeAMon("Water", 100, 100, 100); // Strong legendary MarshCode
        rival.addCodeAMon(marshCode);

        game.addTrainer(player);
        game.addTrainer(rival);

        // Start initial battle
        Battle initialBattle = new Battle(player, rival);
        initialBattle.start();
    }

    private static CodeAMon createRandomCodeAMon(String type) {
        Random rand = new Random();
        int attack = rand.nextInt(5) + 1;  // Random attack between 1 and 5
        int defense = rand.nextInt(5) + 1;  // Random defense between 1 and 5
        int health = 10 + rand.nextInt(5) + 1;  // Base health of 10 plus 1-5
        return new CodeAMon(type, attack, defense, health);
    }
}
