package game;
import java.io.*;

public class SaveGameManager {
    private static final String SAVE_PATH = "gameSave.ser";

    public static void saveGame(Game game) {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(SAVE_PATH))) {
            out.writeObject(game);
        } catch (IOException e) {
            System.err.println("Error saving game: " + e.getMessage());
        }
    }

    public static Game loadGame() {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(SAVE_PATH))) {
            return (Game) in.readObject();
        } catch (FileNotFoundException e) {
            System.out.println("No save file found, starting a new game.");
            return new Game();  
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error loading game: " + e.getMessage());
            return null;
        }
    }

    public static void restartGame() {
        File saveFile = new File(SAVE_PATH);
        if (saveFile.delete()) {
            System.out.println("Save file deleted. Restarting game...");
        } else {
            System.err.println("Failed to delete save file.");
        }
    }
}
