package trainers;
import java.util.ArrayList;
import java.util.List;

import codeamons.*;

public class Trainer {
    private String name;
    private List<CodeAMon> codeAMons;

    public Trainer(String name) {
        this.name = name;
        codeAMons = new ArrayList<>();
    }

    public void addCodeAMon(CodeAMon codeAMon) {
        codeAMons.add(codeAMon);
    }

    public List<CodeAMon> getCodeAMons() {
        return codeAMons;
    }

    public String getName() {
        return name;
    }
}
