package trainers;

public class TrainerFactory {

}
