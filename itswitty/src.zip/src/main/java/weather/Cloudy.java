package weather;

import codeamons.CodeAMon;

public class Cloudy implements Weather {
    @Override
    public void applyEffect(CodeAMon codeAMon) {
        // Cloudy weather might not have any effect or could slightly reduce visibility (accuracy rolls?)
    }
}
