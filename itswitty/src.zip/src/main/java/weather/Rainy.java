package weather;

import codeamons.CodeAMon;

public class Rainy implements Weather {
    @Override
    public void applyEffect(CodeAMon codeAMon) {
        if ("Water".equals(codeAMon.getType())) {
            codeAMon.setAttack((int) (codeAMon.getAttack() * 1.2)); // Increase water type attack by 20%
        }
    }
}
