package weather;

import codeamons.CodeAMon;

public class Stormy implements Weather {
    @Override
    public void applyEffect(CodeAMon codeAMon) {
        if ("Electric".equals(codeAMon.getType())) {
            codeAMon.setAttack((int) (codeAMon.getAttack() * 1.2)); // Increase electric type attack by 20%
        }
    }
}
