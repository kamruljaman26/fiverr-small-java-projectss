package weather;

import codeamons.CodeAMon;

public class Sunny implements Weather {
    @Override
    public void applyEffect(CodeAMon codeAMon) {
        if ("Fire".equals(codeAMon.getType())) {
            codeAMon.setAttack((int) (codeAMon.getAttack() * 1.2)); // Increase fire type attack by 20%
        }
    }
}
