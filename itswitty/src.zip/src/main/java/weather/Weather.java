package weather;

import codeamons.CodeAMon;

public interface Weather {
    void applyEffect(CodeAMon codeAMon);
}
