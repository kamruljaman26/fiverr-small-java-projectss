public class BlackBox {

}
